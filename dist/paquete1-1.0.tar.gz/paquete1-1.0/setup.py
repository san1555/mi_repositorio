from setuptools import setup


setup (
    name= "paquete1",
    version="1.0",
    author="clase 14 coder - Python",
    description="Estamos haciendo el primer paquete distribuido",
    author_email= "Coder@coder.com",
    packages= ["paquete1"]
    ) 

# python setup.py sdist